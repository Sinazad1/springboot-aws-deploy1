package com.example.springboot_aws_deploy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAwsDeployApplicationTests {

	@Test
	void contextLoads() {
	}

}
